#Q1
a<-10
b<-3

#Q2
a+b
a%/%b
a%%b
a^b

#Q3
a>b
b==3
a>5|b<2

#Q4
scores<-c(85,90,78,92,NA,88)
class(scores)
mean(scores,na.rm=TRUE)
scores[scores>80]

#Q5
names<-c("Alice","Bob","Charlie","Diana","Evan","Fiona")
passed<-scores>=80

#Q6
results<-data.frame(Name=names,Score=scores,Passed=passed)

#Q7
str(results)
print(results)

#Q8
max(results$Score, na.rm=TRUE)








