x <- 1:15
sum(x %% 2 == 0)



x <- c(10, 45, 22, 87, 35)

maxIndex <- 1

for(i in 2:length(x)){
  if(x[i] > x[maxIndex]){
    maxIndex <- i
  }
}
print(maxIndex)



x <- c(10,45,22,87,35)

max_index <- which.max(x)

print(max_index)