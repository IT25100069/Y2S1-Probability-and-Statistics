setwd("D:\\IT25100069")
getwd()

# Exercise 01
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

# Exercise 02
pexp(2, rate = 1/3, lower.tail = TRUE)

# Exercise 03 part 1
pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)

# Exercise 03 part 2
qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)