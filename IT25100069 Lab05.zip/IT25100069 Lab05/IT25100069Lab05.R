Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)
Delivery_Times

hist(Delivery_Times$Delivery_Time_,
     breaks = seq(20, 70, length.out = 10),
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")

breaks <- seq(20, 70, length.out = 10)
freq <- hist(Delivery_Times$Delivery_Time_,
             breaks = breaks,
             right = FALSE,
             plot = FALSE)
cum_freq <- cumsum(freq$counts)
cum_freq

plot(freq$breaks[-1], cum_freq,
     type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")
