setwd("D:/PS/IT25100069 PS Lab 10")

snacks <- c(120, 95, 85, 100)

names(snacks) <- c("A", "B", "C", "D")

snacks

chisq.test(snacks)