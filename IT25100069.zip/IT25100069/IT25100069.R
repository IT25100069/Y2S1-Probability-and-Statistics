setwd("C:/Users/MSI/Downloads/IT25100069")

#Q1
studentdata <- read.csv("Exercise.csv")
studentdata

#Q2
summary(studentdata$X1)
hist(studentdata$X1)

#Q3
table(studentdata$X2)
barplot(table(studentdata$X2))

#Q4
boxplot(X1 ~ X3, data=studentdata)
tapply(studentdata$X1, studentdata$X3, mean)
