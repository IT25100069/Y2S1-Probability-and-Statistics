setwd("C:/Users/HP/OneDrive - Sri Lanka Institute of Information Technology/Documents/PS/Lab04")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(data)
attach(branch_data)
head(branch_data)
str(branch_data)
summary(branch_data)
boxplot(branch_data$Sales,main = "Boxplot of Sales",ylab = "Sales")
fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_value <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  outliers <- x[x < lower | x > upper]
  return(outliers)
}
find_outliers(branch_data$Years)
