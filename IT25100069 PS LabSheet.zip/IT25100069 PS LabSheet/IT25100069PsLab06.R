setwd("D:\\IT25100069 PS LabSheet")
getwd()

# EXERCISE 01
n <- 50
p <- 0.85

# Part ii
prob_q1 <- 1 - pbinom(46, 50, 0.85)
prob_q1

# EXERCISE 02
# Part i
lambda <- 12

# Part iii
prob_q2 <- dpois(15, lambda)
prob_q2

